# MCFS [AMPScript] v3.0.1

Greetings Marketing Cloud Experts! You've just updated (or installed) an **AMPscript [MCFS]** extension for Visual Studio Code. This version brings some really cool new features, that I would like to share with you. Share your ideas using [this form](https://docs.google.com/forms/d/e/1FAIpQLSc8NCJcqTxMIIJ5J1pWKTnPY2JewvTS8GU6b9-Lvhdze1N4RA/viewform?usp=sf_link), leave your feedback on the [Extension Page](https://marketplace.visualstudio.com/items?itemName=sergey-agadzhanov.AMPscript) or add a star on my [github repository](https://github.com/Bizcuit/vscode-ampscript).

```diff
+ === NEW FEATURES ===

+ Edit Automation Studio Script Activities (special thanks go to @danielrubiorueda)
+ Edit and Run SQL Queries (special thanks go to Douglas Midgley)
+ Filter and Edit data in Dataextensions (work with DEs like with CSV files)
+ Get dataextension metadata

- IMPORTANT: Additional API permissions are required for the new features to work. 
- Add the following permissions to your MCFS Installed package and restart VS Code:

+ === ADDITIONAL MC PERMISSIONS ===
+ AUTOMATION: Automations (Read, Write, Execute)
+ DATA: Data Extensions (Read, Write)
```

### To run an SQL query
* Connect to your MC account
* Find your SQL Query asset in the "SQL Queries" folder and open a "query.sql" file
* Click a "Run SQL Query" button located in the top right corner of the editor (or run a "MCFS: Run SQL Query" command from the Command Pallet)

![SQL Queries](https://raw.githubusercontent.com/Bizcuit/vscode-ampscript/master/images/mcfs_runquery.jpg)


### To filter a Dataextension
* Connect to your MC account
* Find your Dataextension asset in the "Dataextensions" folder and open a "rows.csv" file
* Click a "Filter a Dataextension" button located in the top right corner of the editor (or run a "MCFS: Filter a Dataextension" command from the Command Pallet)
* Set the filter and hit enter
* Filter example: OrderID = 'ORD2123F2' AND SubscriberKey = 'ABC'

![Dataextensions](https://raw.githubusercontent.com/Bizcuit/vscode-ampscript/master/images/mcfs_filterde.jpg)


## SFMC DevTools published

We have been talking about this behind the scenes already for quite some time but on March 26 the [SFMC DevTools](https://bit.ly/mc-devtools) were finally open-sourced. It allows you to up-/download all kinds of metadata, run mass-deployments to multiple BUs and on top it can be integrated into your IDE or CI/CD solution. And here comes the best part: We are looking into the possibility of integrating it into this VSCode extension.


# Direct connection to Marketing Cloud

## 1. Connect directly to your Marketing Cloud Account

With a quick 5 minutes setup you'll be able to edit content blocks, emails, cloudpages, dataextensions and SQL queries without leaving Visual Studio Code. You can now avoid frequent copy-pasting and focus on your work. Have a look a quick demo below. To open Connection Manager: 
* Press F1 (or 'CMD+Shift+P' on Mac and 'CTRL+Shift+P' on Windows) 
* Start typing 'MCFS'
* Find 'MCFS Connecton Manager' and then press Enter
* You'll find detailed setup instuctions there

![AMPScript](https://raw.githubusercontent.com/Bizcuit/vscode-ampscript/master/images/mcfs.gif)

## 1.a How to connect to Marketing Cloud

As of now, you **can only edit existing assets** (content blocks, emails, cloudpage and json message). Functionality that is not supported at the moment: create new asset, rename asset, move asset to a different folder, delete asset.

* In your MC accout, create a new installed package and add a 'Server-to-Server' API integration Component
* Add the following permissions:
	* CHANNELS: Email (Read and Write)
	* CHANNELS: Web (Read, Write, Publish)
	* ASSETS: Saved Content (Read and Write)
	* AUTOMATION: Automations (Read, Write, Execute)
	* DATA: Data Extensions (Read, Write)
* Grant access to all required BUs
* Provide package details in the connection manager below, save it and connect
* You'll find the entire Content Builder library in your File Explorer tab
* To open Connection Manager next time press F1 (or 'CMD+Shift+P' on Mac and 'CTRL+Shift+P' on Windows) and start typing 'MCFS'. Find 'MCFS Connecton Manager' and then hit Enter

Detailed instructions with screenshots are available directly in the Connection Manager. To open Connection Manager press F1 (or 'CMD+Shift+P' on Mac and 'CTRL+Shift+P' on Windows) and start typing 'MCFS'. Find 'MCFS Connecton Manager' and then hit Enter.

### Assets that you can work with
* Content Builder assets (Emails, Messages and Content Blocks)
* Landing Pages (created with Content Builder editor)
* Dataextensions (Edit data in dataextensions, apply filters, export to CSV etc.)
* SQL Queries (Edit queries and Run them)

### 1.b How to edit assets directly from Visual Studio Code

Each asset is presented as a folder that starts with an 'Ω' symbol. You can easily distinguish different asset types based on the colored square that goes after 'Ω':
* 🟥 - blocks
* 🟦 - emails
* 🟨 - templates
* 🟩 - cloudpages
* 🟪 - mobile messages

Each asset folder includes a readonly '__raw.readonly.json' file. This is an API representation of the asset. You can not modify. Instead you can modify all other files available under the asset folder. Each file represents a specific part of the asset. For the template based email you will see for example smth like: 
* _htmlcontent.amp - template used to create an email
* _subject.amp - subject line of the email
* _preheader.amp - preheader of the email
* s01.b01.content.amp - content of the first content block (b01) that is located in the first template stack/placeholder (s01)
* s01.b01.super.amp - super content of the block above. Learn more about super content [here](https://developer.salesforce.com/docs/atlas.en-us.noversion.mc-apis.meta/mc-apis/design_super_content.htm)
* s01.b02.content.amp - content of the second block in the first template stack
* s01.b02.super.amp - super content of the second block in the first template stack
* s02.b01.content.amp - content of the first block in the second template stack
* s02.b01.super.amp - super content of the first block in the second template stack

## 2. Hover code snippets

Now you can mouse hover a function name in your code and a small popup window including documentation on this function will show up. Check a small example below

![Hover snippets](https://raw.githubusercontent.com/Bizcuit/vscode-ampscript/master/images/screenshot_hoversnippets.jpg)
